public class Problem3 {
    public static void main(String[] args) {
        long n0 = 600851475143L;
        while(true){
            long n1 = removeSmallestFactor(n0);
            if (n1 == -1) {
                System.out.println(n0);
                break;
            }
            n0 = n1;
        }
    }

    public static long removeSmallestFactor(long n) {
        for (int i = 2; i < n; i++) {
            if (isPrime(i) && n % i == 0) {
                return (long)( n / i );
            }
        }

        return -1;
    }

    public static boolean isPrime(int n) {
        for (int i = (int) Math.sqrt(n); i > 1; i--) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }
}
