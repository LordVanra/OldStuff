public class Problem6 {
    public static void main(String[] args) {
        System.out.println(sumSquared(100) - sumSquares(100));
    }
    public static int sumSquares(int n){
        int sum = 0;
        for(int i = 1; i <= n; i++){
            sum += Math.pow(i, 2);
        }
        return sum;
    }
    public static int sumSquared(int n){
        int sum = 0;
        for(int i = 1; i <= n; i++){
            sum += i;
        }
        return (int)Math.pow(sum, 2);
    }
}
