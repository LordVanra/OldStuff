public class Problem7 {
    public static void main(String[] args) {
        int targetN = 10001;
        int n = 0;

        int i = 1;
        while (n != targetN){
            i++;
            if (isPrime(i)){
                n++;
            }
        }

        System.out.println(i);
    }
    public static boolean isPrime(int n) {
        for (int i = (int) Math.sqrt(n); i > 1; i--) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }
}
