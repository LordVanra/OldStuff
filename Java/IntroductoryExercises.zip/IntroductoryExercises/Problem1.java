
public class Problem1 {

    public static void main(String[] args) {
        //Problem 1
        int sum = 0;
        for (int i = 0;i < 1000; i++){
            if(i % 5 == 0 || i % 3 == 0){
                sum += i;
            }
        }
        System.out.println(sum);
        
    }
}
