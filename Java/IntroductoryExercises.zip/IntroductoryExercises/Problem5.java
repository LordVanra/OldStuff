public class Problem5 {
    public static void main(String[] args) {
        int max = 20;

        int mult = 1;

        for(int i = 20; i > 1; i--) {
            if(isPrime(i)){
                int iMaxPower = i;
                while (iMaxPower < max) {
                    iMaxPower *= i;
                }
                mult *= iMaxPower;
                mult /= i;
            }
        }

        System.out.println(mult);
    }

    public static boolean isPrime(int n) {
        for (int i = (int) Math.sqrt(n); i > 1; i--) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }
}
