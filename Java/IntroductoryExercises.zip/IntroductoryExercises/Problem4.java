public class Problem4 {
    
    public static void main(String[] args) {
        int max = 0;
        int maxi = 0;
        int maxj = 0;

        for(int i = 999; i > 0; i--) {
            for(int j = 999; j > 0; j--) {
                int n = i * j;
                if(n > max && String.valueOf(n).equals(new StringBuilder(String.valueOf(n)).reverse().toString())) {
                    max = n;
                    maxi = i;
                    maxj = j;
                }
                if(i < maxi && j < maxj) {
                    break;
                }
            }
        }
        System.out.println(max);
    }
}
