public class Problem10 {
    public static void main(String[] args) {
        int n = 2;
        //AUGH
        long i = 0l;
        while (n < 2000000){
            if (isPrime(n)){
                i+=n;
            }
            
            n++;
        }

        System.out.println(i);
    }
    public static boolean isPrime(int n) {
        for (int i = (int) Math.sqrt(n); i > 1; i--) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }
}
